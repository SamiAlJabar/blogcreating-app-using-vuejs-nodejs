<template>
  <div id="app">
    <router-view/>
  </div>
</template>
<script>
import AuthComp from '@/components/AuthComp.vue';
import MyblogComp from '@/components/MyblogComp.vue';
import ExploreComp from '@/components/ExploreComp.vue';

export default {
  name: 'app',
  components: {
    AuthComp,
    MyblogComp,
    ExploreComp,
  }
}
</script>
<style>
/* ALL CSS FILES */
@import "css/main.css";

</style>
