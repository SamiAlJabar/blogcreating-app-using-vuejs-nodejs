import Vue from 'vue';
import Router from 'vue-router';
import Auth from './views/Auth.vue';
import Myblogs from './views/Myblogs.vue';
import Explore from './views/Explore.vue';
Vue.use(Router);
export default new Router({
  routes: [
    {
      path: '/',
      name: 'auth',
      component: Auth,
    },
    {
      path: '/myblogs',
      name: 'myblogs',
      component: Myblogs,
    },
    {
      path: '/explore',
      name: 'explore',
      component: Explore,
    },
  ],
});
