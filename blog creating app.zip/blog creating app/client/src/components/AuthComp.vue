<template>
  <div>
    <div class="container text-center">
      <form v-if="!openTab || openTab == 1" v-on:submit="login(forms)">
        <div class="form-group" id="signin">
          <h2>SIGN IN</h2>
          <hr>
          <div class="col-md-12">
            <input class="form-control" type="text" placeholder="Username" v-model="forms.username">
          </div>
          <div class="col-md-12">
            <input class="form-control" type="password" placeholder="Password" v-model="forms.password">
          </div>
          <div class="col-md-12">
            <input type="submit" style="width: 100%" class="btn btn-primary buttonAuth" value="GO">
            <span>{{loading}}</span>
          </div>
          <div>
            <p>Do not have an account? <a href="#" v-on:click="openTab = 2">Register</a></p>
          </div>
        </div>
      </form>
      <form v-if="openTab == 2" v-on:submit="signup(forms)">
        <div class="form-group" id="signin">
          <h2>SIGN UP</h2>
          <hr>
          <div class="col-md-12">
            <input class="form-control" type="text" placeholder="Username" v-model="forms.userID" required>
          </div>
          <div class="col-md-12">
            <input class="form-control" type="password" placeholder="Password" v-model="forms.password" required>
          </div>
          <div class="col-md-12">
            <input type="submit" style="width: 100%" class="btn btn-primary buttonAuth" value="REGISTER">
            <span>{{loading}}</span>
          </div>
          <div>
            <p>Already have an account? <a href="#" v-on:click="openTab = 1">Sign In</a></p>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
let port = '';
let host = 'http://';
if(window.location.hostname == 'localhost') {
  port = ':9999';
} else {
  host = 'https://';
}
let API_URL = host+''+window.location.hostname +""+ port;

export default {
  name: 'auth',
  props: {
  },
  data: () => ({
    forms: {
      username: '',
      password: '',
    },
    openTab: 1,
    loading: '',
  }),
  methods: {
    login: function (obj) {
      $('.buttonAuth').hide();
      this.loading = 'Loading ...';
      this.$http.get(API_URL+"/ws/loginProcess?user="+obj.username+"&pass="+obj.password).then(function(response) {
        $('.buttonAuth').show();
        this.loading = '';
        if(response.status == 200) {
          if(response.body[0].result == 'failed') {
            alert("Incorrect username or password!");
          } else {
            sessionStorage.setItem('userIdFromSession', response.body[0].userID);
            alert("Logged in successfully!");
            if(port == ':9999') {
              port = ':8080';
              API_URL = host+''+window.location.hostname +""+ port;
              window.location.href = API_URL+'/#/myblogs';
            } else {
              window.location.href = API_URL+'/#/myblogs';
            }
          }
        } else {
          alert('Server error!');
        }
      });
    },
    signup: function (obj) {
      this.loading = 'Loading ...';
      $('.buttonAuth').hide();
      this.$http.post(API_URL+"/ws/commonInsert?table=Users", obj).then(function(response) {
        $('.buttonAuth').show();
        this.loading = '';
        if(response.status == 200) {
          alert('User registered successfully!');
          this.openTab = 1;
        } else {
          alert('Server Error!');
        }
      });
    },
  },
  mounted() {
    this.loading = '';
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.container {
  padding-left: 20% !important;
  padding-right: 20% !important;
}
#signin {
  margin-top: 170px;
}
hr {
  max-width: 300px;
}
input {
  margin: 10px;
}
a:hover {
  cursor: pointer;
}
</style>
