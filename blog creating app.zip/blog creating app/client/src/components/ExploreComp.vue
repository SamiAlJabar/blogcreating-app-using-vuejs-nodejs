<template>
  <div>
    <div class="container">
      <h3 style="margin-top: 60px" class="text-center">All Blogs</h3>
      <dir v-if="openBlog == 1" class="col-md-12 showblog">
        <div class="col-md-12 showblogInner text-center">
          <h4 style="text-align: left">{{blogTitle}}</h4>
          <p style="font-size: 16px; text-align: left">{{blogDescription}}</p>
          <br>
          <button style="width: 30%" v-if="openBlog == 1" v-on:click="openBlog = 0" class="btn btn-danger">Close</button>
        </div>
      </dir>
      <div style="height: 1px; background-color: #e0e0e0; margin-top: 15px;"></div>
      <div class="col-md-12">
          <div class="eachBlogOut col-md-3 text-center" v-for="blog in myBlogData" :key="blog.id">
            <div class="eachBlog">
              <h4 style="padding-top:5px; padding-bottom:5px;">{{blog.title}}</h4>
              <button v-on:click="openBlogFunc(blog.title, blog.blog)" style="padding-top:5px; padding-bottom:5px; width: 80%" class="btn btn-primary">View</button>
            </div>
          </div>
        </div>
    </div>
  </div>
</template>

<script>
let port = '';
let host = 'http://';
if(window.location.hostname == 'localhost') {
  port = ':9999';
} else {
  host = 'https://';
}
let API_URL = host+''+window.location.hostname +""+ port;

export default {
  name: 'explore',
  props: {
  },
  data: () => ({
    openForm: 0,
    loading: '',
    openBlog: 0,
    blogDescription: '',
    blogTitle: '',
    myBlogData: [],
  }),
  methods: {
    openBlogFunc: function (title, des) {
      this.blogTitle = title;
      this.blogDescription = des;
      this.openBlog = 1;
    },
  },
  mounted() {
    this.$http.get(API_URL+"/ws/commonGet?table=Blogs&key=userID&val=").then(function(response) {
        this.myBlogData = response.body;
    });
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.big-container {
  padding-left: 7% !important;
  padding-right: 7% !important;
}
hr {
  max-width: 300px;
}
input {
  margin: 10px;
}
textarea {
  margin: 10px;
}
a:hover {
  cursor: pointer;
}
#myblogsection {
  margin-top: 50px;
}
.eachBlog {
  background-color: white;
  padding: 15px;
  box-shadow: 2px 2px 4px #969696;
  border-radius: 10px;
}
.eachBlogOut {
  margin-top: 25px;
  display: inline-block;
}
.showblog {
  padding: 15px;
  background-color: white;
  margin-top: 50px;
  border-radius: 10px;
  margin-bottom: 100px;
}
.showblogInner {
  padding: 15px;
}
</style>
