<template>
  <div>
    <!-- NAVBAR -->
    <nav id="mainNavBar" class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="#/">SK BLOG</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarColor01">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="#/myblogs"><b>My Blogs</b> <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#/explore"><b>Explore</b></a>
          </li>
        </ul>
      </div>
    </nav>
    <ExploreComp />
  </div>
</template>

<script>
import ExploreComp from '@/components/ExploreComp.vue';

export default {
  name: 'explore',
  components: {
    ExploreComp,
  },
};
</script>