<template>
  <div>
    <AuthComp />
  </div>
</template>

<script>
import AuthComp from '@/components/AuthComp.vue';

export default {
  name: 'auth',
  components: {
    AuthComp,
  },
};
</script>
