const bodyParser = require('body-parser');
var express = require('express');
var router = express();
var upload = require("express-fileupload");
const cors = require('cors');

router.use(cors());
// var allRoutes = require('./routes');
var dbHandler = require('./dbHandler');

router.use(upload());
router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended: true }));

// Default
// router.get('/', function (req, res) {
//     res.send("Hello Yo!");
// });

// Dynamic Routing
// router.get('/index', function (req, res) {
//     res.sendFile('views/index.html', { root: __dirname });
// });

// Using Web services: GET
router.get('/ws/:webservice', function (req, res) {
    console.log("Get Request!");
    dbHandler.getData(req.params.webservice, req, res);
});
// Using Web services: POST
router.post('/ws/:webservice', function (req, res) {
    dbHandler.getData( req.params.webservice, req, res);
});

// File Upload
router.post('/profilePictureUpload', function (req, res) {
    // var currentDate = new Date();
    if(req.files) {
        // console.log(req.body.imageName);
        // randomString = currentDate.toDateString() + "_" + Math.random().toString(36).substring(7) + "_" +Math.random().toString(36).substring(7)+ "_" + req.files.filename.name;
        req.files.filename.mv("./public/uploads/"+req.body.imageName, function(err){
            if(err) {
                console.log(err);
                res.send("Error Occured!");
            } else {
                // console.log(req);
                // back
                res.redirect(req.body.redirect);
            }
        });
    }
});

module.exports = router;
