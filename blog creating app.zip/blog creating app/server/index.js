const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
var dbHandler = require('./dbHandler');
var allRoutes = require('./routes');
// Middleware
app.use(bodyParser.json());
app.use('/', allRoutes);

const posts = require('./routes/api/posts');
app.use('/api/posts', posts);

// Handle production
if(process.env.NODE_ENV === 'production') {
    console.log("Inside production!");
    // Static Folder
    app.use(express.static(__dirname + '/public/'));

    //Handle SPA
    app.use('/ws/', cors(), allRoutes);
    app.get(/.*/, (req, res) => res.sendFile(__dirname + '/public/index.html'));
} else {
    console.log("Inside 2 production!");
    // Static Folder
    app.use(express.static(__dirname + '/public/'));

    //Handle SPA
    app.use('/ws/', cors(), allRoutes);
    console.log("Dasdsad!");
    app.get(/.*/, (req, res) => res.sendFile(__dirname + '/public/index.html'));
}

const port = process.env.PORT || 9999;

app.listen(port, () => console.log(`Server running on port ${port}`));

// Database Connection
dbHandler.connectToDatabase();