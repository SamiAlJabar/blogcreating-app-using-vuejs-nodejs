var config = {
    dbConfig: {
        user: '',
        password: '',
        server: '',
        database: '',
        port: ,
        options: {
            encrypt: false // USE THIS IF YOU'RE ON WINDOWS AZURE
        }
    }
};

module.exports = config;
