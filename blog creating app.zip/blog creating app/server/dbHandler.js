var mssql = require('mssql');
var Connection = require('tedious').Connection;
var config = require('./config');
var mssqlRequest;
var conn;

exports.connectToDatabase = function() {
    conn = mssql.connect(config.dbConfig, function (err) {
            if (err) {
                console.log(err);
                console.log("... Could not connect to MSSQL Database! ...");
            } else {
                console.log("Inside MSSQL Connect");
            }
            
    });
    mssqlRequest = new mssql.Request(conn);
}

exports.getData = function (webService, req, res) {  
    var wsJSON = '{"ws":"'+webService+'"}';
    console.log(req.body);
    var sqlQuery = "EXECUTE processWebService N'"+wsJSON+"', N'"+JSON.stringify(req.query)+"', N'"+JSON.stringify(req.body)+"'";
    try {
        mssqlRequest.query(sqlQuery, function (err, data) {
            if (err) {
                res.send("Error while executing: " + webService);
                console.log("DB Error while executing <= "+sqlQuery+" => Error: ", err);
                return;
            } else {
                if(!data.recordsets[0]){
                    res.send("[]")
                } else {
                    console.log("Length: " + data.recordsets.length);
                    if(data.recordsets.length > 1) {
                        res.send(JSON.stringify(data.recordsets))
                    } else {
                        res.send(JSON.stringify(data.recordsets[0]))
                    }
                    
                }
            }
        });
    } catch (e) {
        res.send("Error C-001!");
    }
}
